Ask not what Mozilla can do for you but what you can do for Mozilla? 

This project is a place for contributors to start looking for new projects to work on. This will guide you in the right direction depending on your prefered development language.

## Installing Locally

    git clone https://github.com/jdm/asknot asknot
    cd asknot

Start a local HTTP server. There are a lot of ways to do this but here is one
for using python.

For python 2.x

    python -m SimpleHTTPServer 8000

For python 3.x

    python -m http.server 8000

Open [localhost:8000](http://localhost:8000) in your favourite browser!

## Credits

Josh Matthews <josh@joshmatthews.net>

Other contributors listed at https://github.com/jdm/asknot/contributors
